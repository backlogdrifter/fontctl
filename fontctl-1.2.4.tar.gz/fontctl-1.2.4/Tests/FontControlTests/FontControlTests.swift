import Foundation
import FontControl

final class FakeSystem: FontSystem {
    var registrations: [String: Scope] = [:]
    var fontNames: [String: [String]] = [:]
    var externalNames: Set<String> = []
    var registered: [String] = []
    var unregistered: [String] = []
    var failRegister = false
    var failUnregister = false
    func scope(path: String) -> Scope? { registrations[path] }
    func names(path: String) throws -> [String] { fontNames[path] ?? [URL(fileURLWithPath: path).deletingPathExtension().lastPathComponent] }
    func availableNames() -> Set<String> { externalNames.union(registrations.keys.flatMap { fontNames[$0] ?? [URL(fileURLWithPath: $0).deletingPathExtension().lastPathComponent] }) }
    func register(path: String, scope: Scope) throws {
        if failRegister { throw FontError("register failed") }
        registered.append(path); registrations[path] = scope
    }
    func unregister(path: String, scope: Scope) throws {
        if failUnregister { throw FontError("unregister failed") }
        unregistered.append(path); registrations.removeValue(forKey: path)
    }
}
final class FontControlTests {
    var directory: URL!
    func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent("fontctl-tests-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }
    func tearDownWithError() throws { try FileManager.default.removeItem(at: directory) }
    @discardableResult func file(_ relative: String, data: String = "font") throws -> String {
        let url = directory.appendingPathComponent(relative)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try Data(data.utf8).write(to: url); return url.path
    }
    func scanned(_ family: String? = nil) throws -> [FontFile] { try Scanner.scan(root: directory.path, family: family) }
    func testScannerOnlyDirectFontsAndNoSymlinks() throws {
        let a = try file("Family/A.ttf"); let b = try file("Family/B.otf")
        try file("Family/info/Bad.ttf"); try file("Family/duplicates/Bad.otf"); try file("Family/woff/Bad.woff")
        try file("Root.ttf"); try file("info/Bad.ttf"); try file(".hidden/A.ttf")
        try FileManager.default.createSymbolicLink(atPath: directory.appendingPathComponent("Family/Link.ttf").path, withDestinationPath: a)
        expectEqual(try scanned().map(\.path), [b,a])
    }
    func testDryRunDoesNotRegisterOrSaveOrChangeState() throws {
        try file("Family/A.ttf"); let system = FakeSystem(); var state = Registry(); let original = state; var saves = 0
        let result = try Controller(system: system).apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: true, state: &state) { _ in saves += 1 }
        expectEqual(result.counts["would-register"], 1); expectTrue(system.registered.isEmpty)
        expectEqual(saves, 0); expectEqual(state, original)
    }
    func testActivateWritesIntentAndOnlyOwnsSuccessfulRegistration() throws {
        try file("Family/A.ttf"); let system = FakeSystem(); var state = Registry(); var saved: [Registry] = []
        let result = try Controller(system: system).apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { saved.append($0) }
        expectEqual(result.counts["registered"], 1); expectTrue(saved.first!.fonts.values.first!.pending)
        expectFalse(state.fonts.values.first!.pending)
    }
    func testPreexistingFontIsNotOwnedOrDeactivated() throws {
        let path = try file("Family/A.ttf"); let system = FakeSystem(); system.registrations[path] = .session; var state = Registry(); let controller = Controller(system: system)
        let result = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectEqual(result.counts["external"], 1); expectTrue(state.fonts.isEmpty)
        _ = try controller.deactivate(dryRun: false, state: &state) { _ in }
        expectTrue(system.unregistered.isEmpty); expectNotNil(system.registrations[path])
    }
    func testSystemPostScriptConflictIsSkipped() throws {
        try file("Family/A.ttf"); let system = FakeSystem(); system.externalNames = ["A"]; var state = Registry()
        let report = try Controller(system: system).apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectEqual(report.counts["conflict"], 1); expectTrue(system.registered.isEmpty); expectTrue(state.fonts.isEmpty)
    }
    func testDuplicateNamesInBatchChooseOTFAndReportConflict() throws {
        let a = try file("Family/A.ttf"); let b = try file("Family/B.otf"); let system = FakeSystem(); system.fontNames = [a:["Shared"],b:["Shared"]]; var state = Registry()
        let result = try Controller(system: system).apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectEqual(system.registered, [b]); expectEqual(result.counts["conflict"], 1)
    }
    func testSyncUpdatesChangedAndRemovesMissing() throws {
        let a = try file("Family/A.ttf"); let b = try file("Family/B.ttf"); let system = FakeSystem(); let controller = Controller(system: system); var state = Registry()
        _ = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        try FileManager.default.removeItem(atPath: b); try Data("updated".utf8).write(to: URL(fileURLWithPath: a))
        let result = try controller.apply(command: "sync", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectEqual(result.counts["unregistered"], 2); expectEqual(result.counts["registered"], 1)
        expectEqual(Set(state.fonts.keys), [a]); expectEqual(state.fonts[a]?.sha256, try fileHash(a))
    }
    func testFamilySyncLeavesOtherFamilyOwned() throws {
        let a = try file("One/A.ttf"); let b = try file("Two/B.ttf"); let system = FakeSystem(); let controller = Controller(system: system); var state = Registry()
        _ = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        try FileManager.default.removeItem(atPath: a)
        _ = try controller.apply(command: "sync", root: directory.path, files: scanned("One"), scope: .session, family: "One", dryRun: false, state: &state) { _ in }
        expectNotNil(state.fonts[b]); expectNil(state.fonts[a]); expectEqual(system.unregistered, [a])
    }
    func testExpiredSessionIsRegisteredAgain() throws {
        try file("Family/A.ttf"); let system = FakeSystem(); let controller = Controller(system: system); var state = Registry()
        _ = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        system.registrations = [:]
        let result = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectEqual(result.counts["registered"], 1); expectEqual(system.registered.count, 2)
    }
    func testFailedUnregisterKeepsOwnershipAndPreventsReplacement() throws {
        let path = try file("Family/A.ttf"); let system = FakeSystem(); let controller = Controller(system: system); var state = Registry()
        _ = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        let original = state; system.failUnregister = true; try Data("change".utf8).write(to: URL(fileURLWithPath: path))
        let result = try controller.apply(command: "sync", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectTrue(result.hasErrors); expectEqual(state.fonts, original.fonts); expectEqual(system.registered.count, 1)
    }
    func testChangedExternalScopeIsNotUnregistered() throws {
        let path = try file("Family/A.ttf"); let system = FakeSystem(); let controller = Controller(system: system); var state = Registry()
        _ = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        system.registrations[path] = .persistent
        let report = try controller.deactivate(dryRun: false, state: &state) { _ in }
        expectEqual(report.counts["changed-scope"], 1); expectTrue(system.unregistered.isEmpty); expectNotNil(state.fonts[path])
    }
    func testOfflineRootFailsBeforeAnOperationCanBePlanned() throws {
        expectThrows(try Scanner.scan(root: directory.appendingPathComponent("offline").path))
    }
    func testPendingIntentIsRecoveredWithoutRegisteringTwice() throws {
        let path = try file("Family/A.ttf"); let system = FakeSystem(); system.registrations[path] = .session; var state = Registry(); state.root = directory.path
        state.fonts[path] = ManagedFont(path: path, sha256: try fileHash(path), scope: .session, names: ["A"], pending: true)
        let report = try Controller(system: system).apply(command: "sync", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectEqual(report.counts["recovered"], 1); expectFalse(state.fonts[path]!.pending); expectTrue(system.registered.isEmpty)
    }
    func testRegistrationFailureClearsIntent() throws {
        try file("Family/A.ttf"); let system = FakeSystem(); system.failRegister = true; var state = Registry()
        let report = try Controller(system: system).apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        expectEqual(report.counts["error"], 1); expectTrue(state.fonts.isEmpty)
    }
    func testStateValidationRejectsArbitraryOutsideFile() throws {
        let store = StateStore(path: directory.appendingPathComponent("state.json").path); try store.lock()
        var state = Registry(); state.root = directory.path
        state.fonts["/Library/Fonts/System.otf"] = ManagedFont(path: "/Library/Fonts/System.otf", sha256: "x", scope: .persistent, names: ["x"])
        try store.save(state); expectThrows(try store.load())
    }
    func testBadStateIsNotReset() throws {
        let path = try file("state.json", data: "not json"); let store = StateStore(path: path); try store.lock()
        expectThrows(try store.load()); expectEqual(try String(contentsOfFile: path), "not json")
    }
}

extension FontControlTests {
    func sampleRegistry() -> Registry {
        var state = Registry(); state.root = directory.path
        let path = directory.appendingPathComponent("Family/A.ttf").path
        state.fonts[path] = ManagedFont(path: path, sha256: "hash", scope: .session, names: ["A"], pending: true)
        return state
    }
    func testJournalRecoversIntentWithoutSnapshot() throws {
        let path = directory.appendingPathComponent("registry/state.json").path
        let state = sampleRegistry()
        do { let store = StateStore(path: path); try store.lock(); _ = try store.load(); try store.save(state) }
        expectFalse(FileManager.default.fileExists(atPath: path))
        do { let store = StateStore(path: path); try store.lock(); expectEqual(try store.load(), state) }
    }
    func testTornJournalTailIsPreservedAndNextSaveWorks() throws {
        let path = directory.appendingPathComponent("registry/state.json").path
        var state = sampleRegistry()
        do { let store = StateStore(path: path); try store.lock(); try store.save(state) }
        let handle = try FileHandle(forWritingTo: URL(fileURLWithPath: path + ".journal"))
        try handle.seekToEnd(); try handle.write(contentsOf: Data("{broken".utf8)); try handle.close()
        do {
            let store = StateStore(path: path); try store.lock(); expectEqual(try store.load(), state)
            state.fonts[state.fonts.keys.first!]!.pending = false
            try store.save(state); try store.checkpoint(state)
            expectEqual(try store.load(), state)
        }
        let tails = try FileManager.default.contentsOfDirectory(atPath: directory.appendingPathComponent("registry").path).filter { $0.contains(".tail-") }
        expectEqual(tails.count, 1)
    }
    func testMalformedCompleteJournalIsRejected() throws {
        let path = try file("registry/state.json.journal", data: "{broken}\n")
        let store = StateStore(path: String(path.dropLast(".journal".count))); try store.lock()
        expectThrows(try store.load())
        expectEqual(try String(contentsOfFile: path), "{broken}\n")
    }
    func testJournalAppendsOnlyChangedRecordAndCheckpointCompacts() throws {
        let path = directory.appendingPathComponent("registry/state.json").path
        let store = StateStore(path: path); try store.lock()
        var state = Registry(); state.root = directory.path
        for i in 0..<200 {
            let p = directory.appendingPathComponent("Family/Font\(i).ttf").path
            state.fonts[p] = ManagedFont(path: p, sha256: "hash", scope: .session, names: ["Font\(i)"])
        }
        try store.save(state)
        let before = try Data(contentsOf: URL(fileURLWithPath: path + ".journal")).count
        let key = state.fonts.keys.sorted().first!; state.fonts[key]!.pending = true
        try store.save(state)
        let after = try Data(contentsOf: URL(fileURLWithPath: path + ".journal")).count
        expectTrue(after - before < 1000)
        try store.checkpoint(state)
        expectEqual(try Data(contentsOf: URL(fileURLWithPath: path + ".journal")).count, 0)
        expectEqual(try store.load(), state)
    }
}

extension FontControlTests {
    func testDefaultActivationPersistentAndExplicitSession() {
        let state = Registry()
        expectEqual(state.scope, .persistent)
        expectEqual(registrationScope(command: "activate", explicit: nil, state: state, root: directory.path), .persistent)
        expectEqual(registrationScope(command: "activate", explicit: .session, state: state, root: directory.path), .session)
    }
    func testSyncKeepsLegacySessionButEmptyRegistryUsesPersistent() throws {
        var state = sampleRegistry(); state.scope = .session
        expectEqual(registrationScope(command: "sync", explicit: nil, state: state, root: directory.path), .session)
        expectEqual(registrationScope(command: "scan", explicit: nil, state: state, root: directory.path), .session)
        state.fonts = [:]
        expectEqual(registrationScope(command: "sync", explicit: nil, state: state, root: directory.path), .persistent)
    }
    func testDefaultChangeDoesNotMigrateExistingSessionImplicitly() throws {
        let path = try file("Family/A.ttf"); let system = FakeSystem(); let controller = Controller(system: system); var state = Registry()
        _ = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .session, dryRun: false, state: &state) { _ in }
        let scope = registrationScope(command: "activate", explicit: nil, state: state, root: directory.path)
        expectThrows(try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: scope, dryRun: false, state: &state) { _ in })
        expectEqual(system.registrations[path], .session); expectTrue(system.unregistered.isEmpty)
    }
    func testScannerReportsDiscoveryAndHashCompletion() throws {
        try file("Family/A.ttf"); try file("Family/B.otf"); try file("Family/info/Bad.ttf")
        var updates: [ProgressUpdate] = []
        let files = try Scanner.scan(root: directory.path, progress: { updates.append($0) })
        expectEqual(files.count, 2)
        let discovery = updates.filter { $0.phase == .discovery }; let hashing = updates.filter { $0.phase == .hashing }
        expectEqual(discovery.last?.completed, discovery.last?.total)
        expectEqual(hashing.map(\.completed), [0,1,2]); expectEqual(hashing.last?.total, 2)
    }
    func testProcessingProgressIncludesSkippedConflicts() throws {
        try file("Family/A.ttf"); try file("Family/B.otf"); let system = FakeSystem(); system.externalNames = ["A"]
        var state = Registry(); var updates: [ProgressUpdate] = []
        let report = try Controller(system: system).apply(command: "scan", root: directory.path, files: scanned(), scope: .persistent, dryRun: true, state: &state, progress: { updates.append($0) }) { _ in }
        expectEqual(report.counts["conflict"], 1)
        expectEqual(updates.filter { $0.phase == .process }.map(\.completed), [0,1,2])
        expectEqual(updates.last, ProgressUpdate(.process, 2, 2))
    }
    func testStatusAndDeactivateReportProgress() throws {
        try file("Family/A.ttf"); let system = FakeSystem(); let controller = Controller(system: system); var state = Registry()
        _ = try controller.apply(command: "activate", root: directory.path, files: scanned(), scope: .persistent, dryRun: false, state: &state) { _ in }
        var updates: [ProgressUpdate] = []
        _ = controller.status(state: state, progress: { updates.append($0) })
        expectEqual(updates, [ProgressUpdate(.status, 0, 1), ProgressUpdate(.status, 1, 1)])
        updates = []
        _ = try controller.deactivate(dryRun: false, state: &state, progress: { updates.append($0) }) { _ in }
        expectEqual(updates, [ProgressUpdate(.deactivate, 0, 1), ProgressUpdate(.deactivate, 1, 1)])
    }
    func testShortSummaryContainsCountsAndNoFileDetails() {
        var report = RunReport(command: "scan", root: "/secret/root", dryRun: true)
        report.events = [Event("would-register", "/secret/A.ttf", "PrivateName"), Event("conflict", "/secret/B.otf", "conflict reason")]
        let lines = report.shortSummary.components(separatedBy: "\n")
        expectEqual(lines.count, 3)
        expectTrue(lines[0].hasPrefix("Planned:") && lines[0].hasSuffix("2"))
        expectTrue(lines[1].hasPrefix("To activate:") && lines[1].hasSuffix("1"))
        expectTrue(lines[2].hasPrefix("Conflicts:") && lines[2].hasSuffix("1"))
        expectFalse(report.shortSummary.contains("secret")); expectFalse(report.shortSummary.contains("PrivateName"))
        let status = RunReport(command: "status", root: "/secret/root", dryRun: true)
        expectTrue(status.shortSummary.hasPrefix("In registry:") && status.shortSummary.hasSuffix("0"))
    }
}

extension FontControlTests {
    func testRootSettingPersistsCanonicalPath() throws {
        let next = directory.appendingPathComponent("OtherFonts"); try FileManager.default.createDirectory(at: next, withIntermediateDirectories: true)
        let store = StateStore(path: directory.appendingPathComponent("registry/state.json").path); try store.lock()
        var state = try store.load()
        let result = try DirectorySettings.setRoot(next.path, dryRun: false, state: &state, save: store.checkpoint)
        expectEqual(result, canonicalPath(next.path)); expectEqual(try store.load().root, result)
        expectEqual(state.scope, .persistent); expectTrue(state.fonts.isEmpty)
    }
    func testRootDryRunDoesNotSaveOrChangeState() throws {
        var state = Registry(); let before = state; var saves = 0
        let path = try DirectorySettings.setRoot(directory.path, dryRun: true, state: &state) { _ in saves += 1 }
        expectEqual(path, canonicalPath(directory.path)); expectEqual(state, before); expectEqual(saves, 0)
    }
    func testRootChangeRejectsOwnedRegistrations() throws {
        var state = sampleRegistry(); let before = state
        let next = directory.appendingPathComponent("OtherFonts"); try FileManager.default.createDirectory(at: next, withIntermediateDirectories: true)
        var saves = 0
        expectThrows(try DirectorySettings.setRoot(next.path, dryRun: false, state: &state) { _ in saves += 1 })
        expectEqual(state, before); expectEqual(saves, 0)
    }
    func testRootSettingSameManagedRootDoesNotResetOwnership() throws {
        var state = sampleRegistry(); state.root = canonicalPath(directory.path); let before = state; var saves = 0
        _ = try DirectorySettings.setRoot(directory.path, dryRun: false, state: &state) { _ in saves += 1 }
        expectEqual(state, before); expectEqual(saves, 0)
    }
    func testMissingRootDoesNotModifyRegistry() throws {
        var state = Registry(); let before = state; var saves = 0
        expectThrows(try DirectorySettings.setRoot(directory.appendingPathComponent("missing").path, dryRun: false, state: &state) { _ in saves += 1 })
        expectEqual(state, before); expectEqual(saves, 0)
    }
    func testRootSaveFailureLeavesStateUnchanged() throws {
        var state = Registry(); let before = state
        expectThrows(try DirectorySettings.setRoot(directory.path, dryRun: false, state: &state) { _ in throw FontError("disk full") })
        expectEqual(state, before)
    }
}

@main
enum Checks {
 static func main() {
  var failed = 0
  let tests: [(String, (FontControlTests) -> () throws -> Void)] = [
   ("testRootSettingPersistsCanonicalPath", FontControlTests.testRootSettingPersistsCanonicalPath),
   ("testRootDryRunDoesNotSaveOrChangeState", FontControlTests.testRootDryRunDoesNotSaveOrChangeState),
   ("testRootChangeRejectsOwnedRegistrations", FontControlTests.testRootChangeRejectsOwnedRegistrations),
   ("testRootSettingSameManagedRootDoesNotResetOwnership", FontControlTests.testRootSettingSameManagedRootDoesNotResetOwnership),
   ("testMissingRootDoesNotModifyRegistry", FontControlTests.testMissingRootDoesNotModifyRegistry),
   ("testRootSaveFailureLeavesStateUnchanged", FontControlTests.testRootSaveFailureLeavesStateUnchanged),

   ("testDefaultActivationPersistentAndExplicitSession", FontControlTests.testDefaultActivationPersistentAndExplicitSession),
   ("testSyncKeepsLegacySessionButEmptyRegistryUsesPersistent", FontControlTests.testSyncKeepsLegacySessionButEmptyRegistryUsesPersistent),
   ("testDefaultChangeDoesNotMigrateExistingSessionImplicitly", FontControlTests.testDefaultChangeDoesNotMigrateExistingSessionImplicitly),
   ("testScannerReportsDiscoveryAndHashCompletion", FontControlTests.testScannerReportsDiscoveryAndHashCompletion),
   ("testProcessingProgressIncludesSkippedConflicts", FontControlTests.testProcessingProgressIncludesSkippedConflicts),
   ("testStatusAndDeactivateReportProgress", FontControlTests.testStatusAndDeactivateReportProgress),
   ("testShortSummaryContainsCountsAndNoFileDetails", FontControlTests.testShortSummaryContainsCountsAndNoFileDetails),

   ("testJournalRecoversIntentWithoutSnapshot", FontControlTests.testJournalRecoversIntentWithoutSnapshot),
   ("testTornJournalTailIsPreservedAndNextSaveWorks", FontControlTests.testTornJournalTailIsPreservedAndNextSaveWorks),
   ("testMalformedCompleteJournalIsRejected", FontControlTests.testMalformedCompleteJournalIsRejected),
   ("testJournalAppendsOnlyChangedRecordAndCheckpointCompacts", FontControlTests.testJournalAppendsOnlyChangedRecordAndCheckpointCompacts),

   ("testScannerOnlyDirectFontsAndNoSymlinks", FontControlTests.testScannerOnlyDirectFontsAndNoSymlinks),
   ("testDryRunDoesNotRegisterOrSaveOrChangeState", FontControlTests.testDryRunDoesNotRegisterOrSaveOrChangeState),
   ("testActivateWritesIntentAndOnlyOwnsSuccessfulRegistration", FontControlTests.testActivateWritesIntentAndOnlyOwnsSuccessfulRegistration),
   ("testPreexistingFontIsNotOwnedOrDeactivated", FontControlTests.testPreexistingFontIsNotOwnedOrDeactivated),
   ("testSystemPostScriptConflictIsSkipped", FontControlTests.testSystemPostScriptConflictIsSkipped),
   ("testDuplicateNamesInBatchChooseOTFAndReportConflict", FontControlTests.testDuplicateNamesInBatchChooseOTFAndReportConflict),
   ("testSyncUpdatesChangedAndRemovesMissing", FontControlTests.testSyncUpdatesChangedAndRemovesMissing),
   ("testFamilySyncLeavesOtherFamilyOwned", FontControlTests.testFamilySyncLeavesOtherFamilyOwned),
   ("testExpiredSessionIsRegisteredAgain", FontControlTests.testExpiredSessionIsRegisteredAgain),
   ("testFailedUnregisterKeepsOwnershipAndPreventsReplacement", FontControlTests.testFailedUnregisterKeepsOwnershipAndPreventsReplacement),
   ("testChangedExternalScopeIsNotUnregistered", FontControlTests.testChangedExternalScopeIsNotUnregistered),
   ("testOfflineRootFailsBeforeAnOperationCanBePlanned", FontControlTests.testOfflineRootFailsBeforeAnOperationCanBePlanned),
   ("testPendingIntentIsRecoveredWithoutRegisteringTwice", FontControlTests.testPendingIntentIsRecoveredWithoutRegisteringTwice),
   ("testRegistrationFailureClearsIntent", FontControlTests.testRegistrationFailureClearsIntent),
   ("testStateValidationRejectsArbitraryOutsideFile", FontControlTests.testStateValidationRejectsArbitraryOutsideFile),
   ("testBadStateIsNotReset", FontControlTests.testBadStateIsNotReset)
  ]
  for (name, action) in tests {
   let test = FontControlTests(); let previous = failureCount
   do { try test.setUpWithError(); try action(test)() } catch { fail("\(name): \(error)") }
   do { try test.tearDownWithError() } catch { fail("cleanup: \(error)") }
   if failureCount == previous { print("PASS \(name)") } else { failed += 1; print("FAIL \(name)") }
  }
  print("\(tests.count) checks, \(failed) failed")
  exit(failed == 0 ? 0 : 1)
 }
}
