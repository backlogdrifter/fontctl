import Foundation
var failureCount = 0
func fail(_ message: String, file: StaticString = #filePath, line: UInt = #line) {
 failureCount += 1; fputs("\(file):\(line): \(message)\n", stderr)
}
func expectEqual<T: Equatable>(_ left: @autoclosure () throws -> T, _ right: @autoclosure () throws -> T, file: StaticString = #filePath, line: UInt = #line) {
 do { let a = try left(); let b = try right(); if a != b { fail("\(a) != \(b)", file:file,line:line) } } catch { fail("\(error)",file:file,line:line) }
}
func expectTrue(_ value: @autoclosure () throws -> Bool, file: StaticString = #filePath, line: UInt = #line) {
 do { if try !value() { fail("expected true",file:file,line:line) } } catch { fail("\(error)",file:file,line:line) }
}
func expectFalse(_ value: @autoclosure () throws -> Bool, file: StaticString = #filePath, line: UInt = #line) {
 do { if try value() { fail("expected false",file:file,line:line) } } catch { fail("\(error)",file:file,line:line) }
}
func expectNil<T>(_ value: @autoclosure () throws -> T?, file: StaticString = #filePath, line: UInt = #line) {
 do { if try value() != nil { fail("expected nil",file:file,line:line) } } catch { fail("\(error)",file:file,line:line) }
}
func expectNotNil<T>(_ value: @autoclosure () throws -> T?, file: StaticString = #filePath, line: UInt = #line) {
 do { if try value() == nil { fail("expected non-nil",file:file,line:line) } } catch { fail("\(error)",file:file,line:line) }
}
func expectThrows<T>(_ value: @autoclosure () throws -> T, file: StaticString = #filePath, line: UInt = #line) {
 do { _ = try value(); fail("expected error",file:file,line:line) } catch {}
}
