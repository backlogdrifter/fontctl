#!/bin/zsh
set -eu
project_dir=${0:A:h:h}
cd "$project_dir"
swift build -c release --product fontctl
bin_dir=$(swift build -c release --show-bin-path)
mkdir -p "$project_dir/bin"
cp "$bin_dir/fontctl" "$project_dir/bin/fontctl"
chmod 755 "$project_dir/bin/fontctl"
