"""Real CoreText integration; touches only the repository's synthetic font and isolated registry."""
import json, shutil, subprocess, os, pty, errno, threading, select, re
from pathlib import Path
project = Path(__file__).resolve().parent.parent
binary = project / 'bin/fontctl'
work = project / '.build/integration'
root = work / 'Fonts'
family = root / 'Probe'
state = work / 'state.json'
family.mkdir(parents=True, exist_ok=True)
test_env = dict(os.environ)
test_env.pop('FONTCTL_ROOT', None)
test_env['FONTCTL_LANGUAGE'] = 'en'
def run(command, *args, ok=(0,)):
    result = subprocess.run([str(binary), command, '--state', str(state), '--json', *map(str,args)], text=True, capture_output=True, env=test_env)
    if result.returncode not in ok:
        raise RuntimeError(f'{command}: exit {result.returncode}\n{result.stderr}\n{result.stdout}')
    return json.loads(result.stdout) if result.stdout.strip() else {'exit':result.returncode,'stderr':result.stderr}
def tty(command, *args):
    master, slave = pty.openpty()
    output = bytearray()
    done = threading.Event()
    # macOS may discard buffered PTY output when the final slave closes.
    # Keep our slave open and drain concurrently until the child has finished.
    def drain():
        while True:
            readable, _, _ = select.select([master], [], [], 0.05)
            if readable:
                try:
                    chunk = os.read(master, 8192)
                    if not chunk: break
                    output.extend(chunk)
                except OSError as error:
                    if error.errno == errno.EIO: break
                    raise
            elif done.is_set():
                break
    reader = threading.Thread(target=drain, daemon=True)
    reader.start()
    env = dict(test_env, TERM='xterm-256color')
    try:
        process = subprocess.Popen([str(binary), command, '--state', str(state), *map(str,args)], stdout=subprocess.PIPE, stderr=slave, text=True, env=env)
        stdout, _ = process.communicate(timeout=30)
    finally:
        done.set(); reader.join(timeout=5)
        os.close(slave); os.close(master)
    stderr = output.decode('utf-8', errors='replace')
    assert process.returncode == 0, (command, stdout, stderr)
    assert '\x1b' not in stdout and len(stdout.strip().splitlines()) >= 1, stdout
    assert str(root) not in stdout and 'Probe-Regular' not in stdout and 'Probe-Renamed' not in stdout, stdout
    if command in ('scan', 'activate', 'sync'):
        assert re.search(r'\x1b\[38;2;\d+;\d+;\d+m', stderr), stderr
    return stdout, re.sub(r'\x1b\[[0-9;]*m', '', stderr)
results = []
cli_checks = {}
try:
    # Finish any interrupted earlier run using its durable ownership records.
    run('deactivate')
    for scope in ('session', 'persistent'):
        for font in family.glob('*.ttf'):
            font.unlink()
        font = family / 'Probe-Regular.ttf'
        shutil.copyfile(project / 'Tests/Fixtures/FontctlProbe-Regular.ttf', font)
        old = state.read_bytes() if state.exists() else None
        preview = run('activate', '--root', root, '--scope', scope, '--dry-run')
        assert preview['counts'] == {'would-register': 1}, preview
        assert (state.read_bytes() if state.exists() else None) == old
        activated = run('activate', '--root', root, '--scope', scope)
        assert activated['counts'] == {'registered': 1}, activated
        # A separate CLI process must still see the font after activation has exited.
        status = run('status')
        assert status['counts'] == {'active': 1}, status
        repeated = run('activate', '--root', root, '--scope', scope)
        assert repeated['counts'] == {'active': 1}, repeated
        renamed = family / 'Probe-Renamed.ttf'
        font.rename(renamed)
        synced = run('sync', '--root', root, '--scope', scope)
        assert synced['counts'].get('registered') == 1, synced
        assert sum(synced['counts'].get(k,0) for k in ('unregistered','forgotten')) == 1, synced
        assert run('status')['counts'] == {'active': 1}
        # Missing root must not be interpreted as an empty collection.
        offline = work / 'OfflineFonts'
        root.rename(offline)
        try:
            run('sync', '--root', root, ok=(1,))
            assert len(json.loads(state.read_text())['fonts']) == 1
        finally:
            offline.rename(root)
        deactivated = run('deactivate')
        assert deactivated['counts'] == {'unregistered': 1}, deactivated
        assert run('status')['counts'] == {}
        # A fresh activation confirms no registration was left behind.
        again = run('activate', '--root', root, '--scope', scope)
        assert again['counts'] == {'registered': 1}, again
        root.rename(offline)
        try:
            stopped_offline = run('deactivate')
            assert sum(stopped_offline['counts'].get(k,0) for k in ('unregistered','forgotten')) == 1, stopped_offline
        finally:
            offline.rename(root)
        assert run('activate', '--root', root, '--scope', scope)['counts'] == {'registered': 1}
        run('deactivate')
        results.append({'scope':scope,'cross_process_visibility':True,'dry_run':True,'repeat':True,'rename_sync':True,'offline_root':True,'offline_deactivate':True,'deactivate':True})
        print('PASS CoreText ' + scope, flush=True)
    # Existing empty session preferences must not make a new activate temporary.
    empty = json.loads(state.read_text()); assert empty['fonts'] == {}
    empty['scope'] = 'session'; state.write_text(json.dumps(empty))
    activated = run('activate', '--root', root)
    assert activated['counts'] == {'registered': 1}, activated
    assert json.loads(state.read_text())['scope'] == 'persistent'
    assert {r['scope'] for r in json.loads(state.read_text())['fonts'].values()} == {'persistent'}
    cli_checks['default_persistent'] = True
    # Captured stdout is summary-only; details require an explicit flag.
    basic = subprocess.run([str(binary),'scan','--root',str(root),'--state',str(state)],text=True,capture_output=True,check=True)
    assert len(basic.stdout.strip().splitlines()) == 2 and not basic.stderr
    assert str(root) not in basic.stdout and 'Probe-Renamed' not in basic.stdout
    detailed = subprocess.run([str(binary),'scan','--root',str(root),'--state',str(state),'--verbose'],text=True,capture_output=True,check=True)
    assert str(root) in detailed.stdout and '[active]' in detailed.stdout
    cli_checks['summary_without_details'] = True
    cli_checks['verbose_details'] = True
    _, progress = tty('scan', '--root', root)
    assert all(s in progress for s in ('Scanning folders','Reading files','Checking fonts','1/1','\x1b[2K')), progress
    _, progress = tty('sync', '--root', root)
    assert 'Synchronizing' in progress and 'Checking registrations' in progress, progress
    _, progress = tty('status')
    assert 'Checking status' in progress and '1/1' in progress, progress
    _, progress = tty('deactivate')
    assert 'Deactivating' in progress and '1/1' in progress, progress
    _, progress = tty('activate', '--root', root)
    assert 'Activating' in progress and '1/1' in progress, progress
    _, progress = tty('status', '--no-progress')
    assert progress == '', progress
    cli_checks['tty_progress_all_commands'] = True
    cli_checks['no_progress'] = True
    print('PASS CLI defaults, summary, verbose and TTY progress', flush=True)
    # Durable root settings must be usable without --root in subsequent processes.
    new_root = work / 'New Fonts'
    new_family = new_root / 'Probe'
    new_family.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(project / 'Tests/Fixtures/FontctlProbe-Regular.ttf', new_family/'Probe-Regular.ttf')
    before = state.read_bytes()
    blocked = run('root', 'set', new_root, ok=(1,))
    assert 'deactivate' in blocked['stderr'] and state.read_bytes() == before
    run('deactivate')
    before = state.read_bytes()
    preview = run('root', 'set', new_root, '--dry-run')
    assert preview['root'] == str(new_root) and preview['dryRun'] and not preview['changed']
    assert state.read_bytes() == before
    assert run('root', 'get')['root'] == str(root)
    changed = run('root', 'set', new_root)
    assert changed['root'] == str(new_root) and changed['changed']
    assert run('root')['root'] == str(new_root)
    assert run('root', 'get')['root'] == str(new_root)
    # Even an older fallback config cannot mask the new saved root.
    config = work/'old-config.json'
    config.write_text(json.dumps({'root': str(root)}))
    scanned = run('scan', '--config', config)
    assert scanned['counts'] == {'would-register': 1} and scanned['root'] == str(new_root), scanned
    assert run('activate')['counts'] == {'registered': 1}
    assert run('sync')['counts'] == {'active': 1}
    assert run('status')['counts'] == {'active': 1}
    run('deactivate')
    before = state.read_bytes()
    run('root', 'set', work/'missing-directory', ok=(1,))
    assert state.read_bytes() == before
    assert run('root', 'get')['root'] == str(new_root)
    # The saved path remains visible when the disk/directory is unavailable.
    moved = work/'OfflineNewFonts'
    new_root.rename(moved)
    try:
        assert run('root', 'get')['root'] == str(new_root)
    finally:
        moved.rename(new_root)
    for arguments in (['help'], ['--help'], ['-h']):
        help_result = subprocess.run([str(binary), *arguments],text=True,capture_output=True,check=True,env=test_env)
        assert not help_result.stderr
        plain_help = re.sub(r'\x1b\[[0-9;]*m', '', help_result.stdout)
        assert all(text in plain_help for text in ('1.2.4', 'Author: backlogdrifter', 'Build:', 'COMMANDS', 'EXAMPLES', 'NOTES', 'lang ru|en', 'fctl', 'scan', 'activate', 'sync', 'deactivate', 'status', 'list', 'authors', 'root get', 'root set'))
    cli_checks['help_all_features'] = True
    cli_checks['root_set_get_and_dry_run'] = True
    cli_checks['root_change_blocks_owned_registrations'] = True
    cli_checks['new_root_used_by_scan_activate_sync'] = True
    cli_checks['root_get_works_offline'] = True
    print('PASS help and durable root change, including subsequent activation', flush=True)
finally:
    cleanup = subprocess.run([str(binary), 'deactivate', '--state', str(state), '--json'], text=True, capture_output=True, env=test_env)
    if cleanup.returncode != 0:
        print('CLEANUP FAILED:', cleanup.stderr, cleanup.stdout, flush=True)
        raise RuntimeError('Тестовые регистрации не удалось снять; состояние сохранено: ' + str(state))
work.mkdir(parents=True, exist_ok=True)
(work/'result.json').write_text(json.dumps({'tests':results,'cli_checks':cli_checks,'cleanup':'passed'},ensure_ascii=False,indent=2))
print('CoreText integration passed; synthetic registrations removed.', flush=True)
