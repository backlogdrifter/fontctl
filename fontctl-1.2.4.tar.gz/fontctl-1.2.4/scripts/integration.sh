#!/bin/zsh
set -eu
project_dir=${0:A:h:h}
cd "$project_dir"
if [[ ! -x bin/fontctl ]]; then ./scripts/build.sh; fi
exec python3 "$project_dir/scripts/integration.py"
