#!/bin/zsh
set -eu
project_dir=${0:A:h:h}
cd "$project_dir"
swift run fontctl-checks
