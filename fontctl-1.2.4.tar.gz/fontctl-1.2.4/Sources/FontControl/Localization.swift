import Foundation

public enum Localization {
    public static var language = "en"
    public static func text(_ english: String, _ russian: String) -> String {
        language == "ru" ? russian : english
    }
    public static func translate(_ value: String) -> String {
        guard language == "en" else { return value }
        let replacements: [(String, String)] = [
            ("Неизвестная команда:", "Unknown command:"), ("Неизвестный аргумент:", "Unknown argument:"),
            ("Нет значения для", "Missing value for"), ("Путь указан дважды", "Path specified twice"),
            ("Режим: session или persistent", "Scope must be session or persistent"),
            ("Недопустимая операция", "Invalid operation"),
            ("Папка недоступна:", "Folder unavailable:"), ("Регистрации не изменены; проверьте внешний диск.", "Registrations unchanged; check the external drive."),
            ("Гарнитура не найдена:", "Family not found:"),
            ("Уже управляется другая папка:", "Another folder is already managed:"),
            ("Сначала выполните deactivate для неё или используйте отдельный --state.", "Deactivate it first or use a separate --state."),
            ("Сначала deactivate, затем activate с новым --scope. Режим существующих регистраций не меняется автоматически.", "Run deactivate, then activate with the new --scope. Existing registrations do not migrate automatically."),
            ("Регистрация изменена извне; не отключена", "Registration changed externally; not deactivated"),
            ("Файл изменился", "File changed"), ("Файл удалён или переименован", "File removed or renamed"),
            ("Старая регистрация не отключена; обновление пропущено", "Previous registration was not removed; update skipped"),
            ("Режим регистрации изменён другим менеджером", "Registration scope changed by another manager"),
            ("Уже зарегистрирован вне fontctl; управление не присвоено", "Already registered outside fontctl; ownership not claimed"),
            ("PostScript-имя уже доступно:", "PostScript name already in use:"),
            ("Файл изменился во время сканирования; пропущен", "File changed during scan; skipped"),
            ("Режим изменён извне; регистрация не отключена", "Scope changed externally; registration not removed"),
            ("файл недоступен", "file unavailable"), ("незавершённая запись, выполните sync", "pending record; run sync"),
            ("Другой экземпляр fontctl уже работает с этим состоянием", "Another fontctl process is using this state"),
            ("Не удалось открыть блокировку состояния:", "Could not open state lock:"),
            ("Не удалось прочитать состояние", "Could not read state"), ("Файл не перезаписан.", "File was not overwritten."),
            ("Повреждён журнал", "Journal is corrupted"), ("автоматическая перезапись запрещена", "automatic overwrite is disabled"),
            ("Повреждён заголовок журнала", "Corrupt journal header"),
            ("Повреждённая запись шрифта в журнале", "Corrupt font record in journal"),
            ("Повреждённая запись удаления в журнале", "Corrupt removal record in journal"),
            ("Неизвестная операция в журнале состояния", "Unknown state journal operation"),
            ("Неподдерживаемая версия состояния:", "Unsupported state version:"),
            ("Недопустимая запись состояния:", "Invalid state record:"),
            ("Не удалось открыть журнал состояния", "Could not open state journal"),
            ("Не удалось сохранить повреждённый хвост журнала", "Could not preserve damaged journal tail"),
            ("Не удалось ограничить доступ к файлу состояния", "Could not restrict state file permissions"),
            ("CoreText не распознал шрифт", "CoreText did not recognize the font"),
            ("Отсутствует пригодное внутреннее PostScript-имя; имя файла это не исправляет", "No valid internal PostScript name; the file name cannot fix this"),
            ("CoreText вернул ошибку без описания", "CoreText returned an error without a description"),
            ("Сохранённый путь не изменён.", "Saved path unchanged."),
            ("Текущие регистрации не изменены.", "Current registrations unchanged."),
            ("--family и --scope не используются с root", "--family and --scope cannot be used with root"),
            ("Укажите путь: fontctl root set", "Provide a path: fontctl root set"),
            ("Для смены пути используйте root set ПУТЬ", "Use root set PATH to change the collection path"),
            ("--family должен содержать одно имя папки", "--family must contain one folder name"),
            ("--scope задаётся при activate/sync", "--scope is used with activate/sync"),
            ("Отчёт не может перезаписывать состояние или журнал", "Report cannot overwrite state or journal"),
            ("Отчёт не может перезаписывать файл состояния", "Report cannot overwrite the state file"),
            ("Этот --state относится к другой папке:", "This --state belongs to a different folder:"),
            ("Папка не задана. Используйте fontctl root set ПУТЬ", "No collection path set. Use fontctl root set PATH"),
            ("Укажите путь к Fonts или используйте проектный launcher ./fontctl", "Provide a Fonts path or use the project launcher ./fontctl"),
            ("Есть управляемые регистрации старой папки.", "The previous folder still has managed registrations."),
            ("Сначала fontctl deactivate, затем fontctl root set", "Run fontctl deactivate, then fontctl root set"),
            ("/путь/к/Fonts", "/path/to/Fonts"), ("ПУТЬ", "PATH")
        ]
        return replacements.reduce(value) { $0.replacingOccurrences(of: $1.0, with: $1.1) }
    }
}
