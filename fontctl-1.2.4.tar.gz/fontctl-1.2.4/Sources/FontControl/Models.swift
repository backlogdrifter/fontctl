import Foundation
import CryptoKit

public enum Scope: String, Codable { case session, persistent }
public struct ManagedFont: Codable, Equatable {
    public var path: String
    public var sha256: String
    public var scope: Scope
    public var names: [String]
    public var pending: Bool
    public init(path: String, sha256: String, scope: Scope, names: [String], pending: Bool = false) {
        self.path = path; self.sha256 = sha256; self.scope = scope; self.names = names; self.pending = pending
    }
}
public struct Registry: Codable, Equatable {
    public var version = 1
    public var root: String?
    public var scope: Scope = .persistent
    public var fonts: [String: ManagedFont] = [:]
    public init() {}
}
public struct FontFile {
    public let path: String
    public let sha256: String
    public init(path: String, sha256: String) { self.path = path; self.sha256 = sha256 }
}
public struct Event: Codable {
    public let action: String
    public let path: String
    public let detail: String
    public init(_ action: String, _ path: String, _ detail: String = "") {
        self.action = action; self.path = path; self.detail = Localization.translate(detail)
    }
}
public struct RunReport: Encodable {
    public let command: String
    public let root: String
    public let dryRun: Bool
    public var events: [Event] = []
    public var counts: [String: Int] { Dictionary(events.map { ($0.action, 1) }, uniquingKeysWith: +) }
    public var hasErrors: Bool { events.contains { ["error", "conflict", "invalid", "changed-scope"].contains($0.action) } }
    public init(command: String, root: String, dryRun: Bool) { self.command = command; self.root = root; self.dryRun = dryRun }
    enum CodingKeys: String, CodingKey { case command, root, dryRun, events, counts }
    public func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(command, forKey: .command); try c.encode(root, forKey: .root)
        try c.encode(dryRun, forKey: .dryRun); try c.encode(events, forKey: .events); try c.encode(counts, forKey: .counts)
    }
}
public struct FontError: Error, LocalizedError {
    public let message: String
    public let code: Int?
    public init(_ message: String, code: Int? = nil) { self.message = Localization.translate(message); self.code = code }
    public var errorDescription: String? { message }
}
public func canonicalPath(_ path: String) -> String {
    URL(fileURLWithPath: (path as NSString).expandingTildeInPath).standardizedFileURL.resolvingSymlinksInPath().path
}
public func fileHash(_ path: String) throws -> String {
    let handle = try FileHandle(forReadingFrom: URL(fileURLWithPath: path))
    defer { try? handle.close() }
    var hasher = SHA256()
    while let data = try handle.read(upToCount: 1_048_576), !data.isEmpty { hasher.update(data: data) }
    return hasher.finalize().map { String(format: "%02x", $0) }.joined()
}
public enum Scanner {
    public static func scan(root: String, family: String? = nil, progress: ProgressCallback? = nil, hashFiles: Bool = true) throws -> [FontFile] {
        progress?(ProgressUpdate(.discovery, 0, 0))
        let fm = FileManager.default; let url = URL(fileURLWithPath: root)
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: root, isDirectory: &isDir), isDir.boolValue else {
            throw FontError("Папка недоступна: \(root). Регистрации не изменены; проверьте внешний диск.")
        }
        let keys: [URLResourceKey] = [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey]
        let entries = try fm.contentsOfDirectory(at: url, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])
        let families = try entries.filter {
            let values = try $0.resourceValues(forKeys: Set(keys))
            return values.isDirectory == true && values.isSymbolicLink != true &&
                !["info", "woff", "duplicates"].contains($0.lastPathComponent.lowercased())
        }
        if let family, !families.contains(where: { $0.lastPathComponent == family }) {
            throw FontError("Гарнитура не найдена: \(family)")
        }
        let folders = families.filter { family == nil || $0.lastPathComponent == family }
        var candidates: [String] = []
        progress?(ProgressUpdate(.discovery, 0, folders.count))
        for (index, folder) in folders.enumerated() {
            defer { progress?(ProgressUpdate(.discovery, index + 1, folders.count)) }
            let values = try folder.resourceValues(forKeys: Set(keys))
            guard values.isDirectory == true, values.isSymbolicLink != true,
                  !["info", "woff", "duplicates"].contains(folder.lastPathComponent.lowercased()),
                  family == nil || folder.lastPathComponent == family else { continue }
            for file in try fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) {
                let values = try file.resourceValues(forKeys: Set(keys))
                guard values.isRegularFile == true, values.isSymbolicLink != true,
                      ["ttf", "otf"].contains(file.pathExtension.lowercased()) else { continue }
                candidates.append(file.standardizedFileURL.path)
            }
        }
        // Deterministic preference when different files declare the same PostScript name.
        candidates.sort {
            let a = URL(fileURLWithPath: $0).pathExtension.lowercased() == "otf"
            let b = URL(fileURLWithPath: $1).pathExtension.lowercased() == "otf"
            return a == b ? $0 < $1 : a
        }
        progress?(ProgressUpdate(.hashing, 0, candidates.count))
        var files: [FontFile] = []
        for (index, path) in candidates.enumerated() {
            files.append(FontFile(path: path, sha256: hashFiles ? try fileHash(path) : ""))
            progress?(ProgressUpdate(.hashing, index + 1, candidates.count))
        }
        return files
    }
}
public protocol FontSystem: AnyObject {
    func scope(path: String) -> Scope?
    func names(path: String) throws -> [String]
    func availableNames() -> Set<String>
    func register(path: String, scope: Scope) throws
    func unregister(path: String, scope: Scope) throws
}
