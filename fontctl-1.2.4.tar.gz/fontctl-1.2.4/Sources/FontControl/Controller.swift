import Foundation

public final class Controller {
    private let system: FontSystem
    public init(system: FontSystem) { self.system = system }
    private func selected(_ path: String, family: String?) -> Bool {
        family == nil || URL(fileURLWithPath: path).deletingLastPathComponent().lastPathComponent == family
    }
    public func apply(command: String, root: String, files: [FontFile], scope: Scope,
                      family: String? = nil, dryRun: Bool, state: inout Registry,
                      progress: ProgressCallback? = nil, save: (Registry) throws -> Void) throws -> RunReport {
        guard ["activate", "sync", "scan"].contains(command) else { throw FontError("Недопустимая операция") }
        if let previous = state.root, previous != root, !state.fonts.isEmpty {
            throw FontError("Уже управляется другая папка: \(previous). Сначала выполните deactivate для неё или используйте отдельный --state.")
        }
        if !state.fonts.isEmpty && state.fonts.values.contains(where: { $0.scope != scope }) {
            throw FontError("Сначала deactivate, затем activate с новым --scope. Режим существующих регистраций не меняется автоматически.")
        }
        var work = state
        work.root = root; work.scope = scope
        var report = RunReport(command: command, root: root, dryRun: dryRun)
        let candidates = Dictionary(uniqueKeysWithValues: files.map { ($0.path, $0) })
        var simulatedRemoved = Set<String>()
        var removedNames = Set<String>()
        // A failed scan never reaches this method. An offline drive cannot trigger a bulk unregister.
        let paths = work.fonts.keys.sorted().filter { selected($0, family: family) }
        progress?(ProgressUpdate(.reconcile, 0, paths.count))
        for (index, path) in paths.enumerated() {
            defer { progress?(ProgressUpdate(.reconcile, index + 1, paths.count)) }
            guard let record = work.fonts[path] else { continue }
            let changed = candidates[path].map { $0.sha256 != record.sha256 } ?? false
            let removed = command == "sync" && candidates[path] == nil
            guard changed || removed else { continue }
            let actual = system.scope(path: path)
            if let actual, actual != record.scope {
                report.events.append(Event("changed-scope", path, "Регистрация изменена извне; не отключена")); continue
            }
            if dryRun {
                report.events.append(Event(actual == nil ? "would-forget" : "would-unregister", path, changed ? "Файл изменился" : "Файл удалён или переименован"))
                simulatedRemoved.insert(path); removedNames.formUnion(record.names); work.fonts.removeValue(forKey: path)
            } else {
                if actual != nil {
                    do { try system.unregister(path: path, scope: record.scope) }
                    catch let error as FontError where error.code == 201 { /* already unregistered */ }
                    catch { report.events.append(Event("error", path, error.localizedDescription)); continue }
                }
                work.fonts.removeValue(forKey: path); try save(work)
                report.events.append(Event(actual == nil ? "forgotten" : "unregistered", path))
            }
        }
        var available = system.availableNames()
        if dryRun { available.subtract(removedNames) }
        progress?(ProgressUpdate(.process, 0, files.count))
        for (index, file) in files.enumerated() {
            defer { progress?(ProgressUpdate(.process, index + 1, files.count)) }
            if let record = work.fonts[file.path] {
                guard record.sha256 == file.sha256 else {
                    report.events.append(Event("error", file.path, "Старая регистрация не отключена; обновление пропущено")); continue
                }
                let current = system.scope(path: file.path)
                if current == record.scope {
                    if record.pending && !dryRun {
                        work.fonts[file.path]?.pending = false; try save(work)
                    }
                    report.events.append(Event(record.pending ? "recovered" : "active", file.path)); continue
                }
                if current != nil {
                    report.events.append(Event("changed-scope", file.path, "Режим регистрации изменён другим менеджером")); continue
                }
                // Session registration may have expired after logout; keep the same file eligible.
                work.fonts.removeValue(forKey: file.path)
            }
            if system.scope(path: file.path) != nil && !simulatedRemoved.contains(file.path) {
                report.events.append(Event("external", file.path, "Уже зарегистрирован вне fontctl; управление не присвоено")); continue
            }
            let names: [String]
            do { names = try system.names(path: file.path) }
            catch { report.events.append(Event("invalid", file.path, error.localizedDescription)); continue }
            let collisions = names.filter { available.contains($0) }
            guard collisions.isEmpty else {
                report.events.append(Event("conflict", file.path, "PostScript-имя уже доступно: " + collisions.joined(separator: ", "))); continue
            }
            if dryRun {
                report.events.append(Event("would-register", file.path, names.joined(separator: ", ")))
                available.formUnion(names); continue
            }
            guard try fileHash(file.path) == file.sha256 else {
                report.events.append(Event("error", file.path, "Файл изменился во время сканирования; пропущен")); continue
            }
            // Write intent first, so a crash between CoreText and the next save is recoverable.
            work.fonts[file.path] = ManagedFont(path: file.path, sha256: file.sha256, scope: scope, names: names, pending: true)
            try save(work)
            do { try system.register(path: file.path, scope: scope) }
            catch {
                work.fonts.removeValue(forKey: file.path); try save(work)
                report.events.append(Event("error", file.path, error.localizedDescription))
                available = system.availableNames(); continue
            }
            work.fonts[file.path]?.pending = false; try save(work)
            available.formUnion(names)
            report.events.append(Event("registered", file.path, names.joined(separator: ", ")))
        }
        if !dryRun { try save(work); state = work }
        return report
    }
    public func deactivate(family: String? = nil, dryRun: Bool, state: inout Registry,
                           progress: ProgressCallback? = nil, save: (Registry) throws -> Void) throws -> RunReport {
        var work = state
        var report = RunReport(command: "deactivate", root: state.root ?? "", dryRun: dryRun)
        let paths = work.fonts.keys.sorted().filter { selected($0, family: family) }
        progress?(ProgressUpdate(.deactivate, 0, paths.count))
        for (index, path) in paths.enumerated() {
            defer { progress?(ProgressUpdate(.deactivate, index + 1, paths.count)) }
            guard let record = work.fonts[path] else { continue }
            let actual = system.scope(path: path)
            if let actual, actual != record.scope {
                report.events.append(Event("changed-scope", path, "Режим изменён извне; регистрация не отключена")); continue
            }
            if dryRun {
                report.events.append(Event(actual == nil ? "would-forget" : "would-unregister", path)); continue
            }
            if actual != nil {
                do { try system.unregister(path: path, scope: record.scope) }
                catch let error as FontError where error.code == 201 { /* idempotent */ }
                catch { report.events.append(Event("error", path, error.localizedDescription)); continue }
            }
            work.fonts.removeValue(forKey: path); try save(work)
            report.events.append(Event(actual == nil ? "forgotten" : "unregistered", path))
        }
        if !dryRun { state = work }
        return report
    }
    public func status(state: Registry, family: String? = nil, progress: ProgressCallback? = nil) -> RunReport {
        var report = RunReport(command: "status", root: state.root ?? "", dryRun: true)
        let paths = state.fonts.keys.sorted().filter { selected($0, family: family) }
        progress?(ProgressUpdate(.status, 0, paths.count))
        for (index, path) in paths.enumerated() {
            defer { progress?(ProgressUpdate(.status, index + 1, paths.count)) }
            guard let record = state.fonts[path] else { continue }
            let scope = system.scope(path: path)
            let exists = FileManager.default.fileExists(atPath: path)
            let action = scope == record.scope ? "active" : scope == nil ? "inactive" : "changed-scope"
            report.events.append(Event(action, path, "\(record.scope.rawValue)\(exists ? "" : "; файл недоступен")\(record.pending ? "; незавершённая запись, выполните sync" : "")"))
        }
        return report
    }
}
