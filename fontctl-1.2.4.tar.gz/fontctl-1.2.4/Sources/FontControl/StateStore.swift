import Foundation
import Darwin

private struct JournalEntry: Codable {
    var operation: String
    var root: String?
    var scope: Scope?
    var font: ManagedFont?
    var path: String?
}
public final class StateStore {
    public let url: URL
    private var journalURL: URL { URL(fileURLWithPath: url.path + ".journal") }
    private var lockFD: Int32 = -1
    private var persistedRoot: String?
    private var persistedScope: Scope = .persistent
    private var persistedFonts: [String: ManagedFont] = [:]
    private var validJournalBytes: UInt64 = 0
    public init(path: String) { url = URL(fileURLWithPath: (path as NSString).expandingTildeInPath).standardizedFileURL }
    public func lock() throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        lockFD = Darwin.open(url.path + ".lock", O_CREAT | O_RDWR | O_NOFOLLOW, 0o600)
        guard lockFD >= 0 else { throw FontError("Не удалось открыть блокировку состояния: \(String(cString: strerror(errno)))") }
        guard flock(lockFD, LOCK_EX | LOCK_NB) == 0 else { throw FontError("Другой экземпляр fontctl уже работает с этим состоянием") }
    }
    deinit { if lockFD >= 0 { _ = flock(lockFD, LOCK_UN); Darwin.close(lockFD) } }
    public func load() throws -> Registry {
        var state = Registry()
        if FileManager.default.fileExists(atPath: url.path) {
            do { state = try JSONDecoder().decode(Registry.self, from: Data(contentsOf: url)) }
            catch { throw FontError("Не удалось прочитать состояние \(url.path): \(error.localizedDescription). Файл не перезаписан.") }
        }
        if FileManager.default.fileExists(atPath: journalURL.path) {
            let data = try Data(contentsOf: journalURL)
            // Only a newline-terminated record is committed. A torn last write is ignored,
            // but a malformed complete record is an error, never silently discarded.
            let valid = data.lastIndex(of: 10).map { Data(data.prefix(through: $0)) } ?? Data()
            validJournalBytes = UInt64(valid.count)
            for line in valid.split(separator: 10) {
                let entry: JournalEntry
                do { entry = try JSONDecoder().decode(JournalEntry.self, from: Data(line)) }
                catch { throw FontError("Повреждён журнал \(journalURL.path); автоматическая перезапись запрещена") }
                switch entry.operation {
                case "header":
                    guard let scope = entry.scope else { throw FontError("Повреждён заголовок журнала") }
                    state.root = entry.root; state.scope = scope
                case "upsert":
                    guard let font = entry.font else { throw FontError("Повреждённая запись шрифта в журнале") }
                    state.fonts[font.path] = font
                case "remove":
                    guard let path = entry.path else { throw FontError("Повреждённая запись удаления в журнале") }
                    state.fonts.removeValue(forKey: path)
                default: throw FontError("Неизвестная операция в журнале состояния")
                }
            }
        }
        guard state.version == 1 else { throw FontError("Неподдерживаемая версия состояния: \(state.version)") }
        for (key, record) in state.fonts {
            guard key == record.path, let root = state.root,
                  URL(fileURLWithPath: record.path).deletingLastPathComponent().deletingLastPathComponent().path == root,
                  ["otf", "ttf"].contains(URL(fileURLWithPath: record.path).pathExtension.lowercased()) else {
                throw FontError("Недопустимая запись состояния: \(key)")
            }
        }
        persistedRoot = state.root; persistedScope = state.scope; persistedFonts = state.fonts
        return state
    }
    public func save(_ state: Registry) throws {
        var entries: [JournalEntry] = []
        if persistedRoot != state.root || persistedScope != state.scope {
            entries.append(JournalEntry(operation: "header", root: state.root, scope: state.scope))
        }
        for path in persistedFonts.keys where state.fonts[path] == nil {
            entries.append(JournalEntry(operation: "remove", path: path))
        }
        for path in state.fonts.keys where state.fonts[path] != persistedFonts[path] {
            entries.append(JournalEntry(operation: "upsert", font: state.fonts[path]))
        }
        guard !entries.isEmpty else { return }
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        var bytes = Data()
        for entry in entries { bytes.append(try encoder.encode(entry)); bytes.append(10) }
        let fd = Darwin.open(journalURL.path, O_CREAT | O_RDWR | O_NOFOLLOW, 0o600)
        guard fd >= 0 else { throw FontError("Не удалось открыть журнал состояния") }
        let handle = FileHandle(fileDescriptor: fd, closeOnDealloc: true)
        defer { try? handle.close() }
        // Preserve a torn tail for diagnosis before removing it on the next mutation.
        let size = try handle.seekToEnd()
        if size > validJournalBytes {
            try handle.seek(toOffset: validJournalBytes)
            let tail = try handle.readToEnd() ?? Data()
            let backup = URL(fileURLWithPath: journalURL.path + ".tail-" + UUID().uuidString)
            guard FileManager.default.createFile(atPath: backup.path, contents: tail, attributes: [.posixPermissions: 0o600]) else { throw FontError("Не удалось сохранить повреждённый хвост журнала") }
        }
        try handle.truncate(atOffset: validJournalBytes); try handle.seekToEnd()
        try handle.write(contentsOf: bytes); try handle.synchronize()
        validJournalBytes += UInt64(bytes.count)
        persistedRoot = state.root; persistedScope = state.scope
        // Keep a separate dictionary: do not retain a COW snapshot of the caller on every save.
        for entry in entries {
            if let path = entry.path, entry.operation == "remove" { persistedFonts.removeValue(forKey: path) }
            if let font = entry.font { persistedFonts[font.path] = font }
        }
    }
    public func checkpoint(_ state: Registry) throws {
        try save(state)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        try encoder.encode(state).write(to: url, options: .atomic)
        guard chmod(url.path, 0o600) == 0 else { throw FontError("Не удалось ограничить доступ к файлу состояния") }
        let snapshot = try FileHandle(forWritingTo: url)
        defer { try? snapshot.close() }
        try snapshot.synchronize()
        if FileManager.default.fileExists(atPath: journalURL.path) {
            let journal = try FileHandle(forWritingTo: journalURL)
            defer { try? journal.close() }
            try journal.truncate(atOffset: 0); try journal.synchronize(); validJournalBytes = 0
        }
    }
}
