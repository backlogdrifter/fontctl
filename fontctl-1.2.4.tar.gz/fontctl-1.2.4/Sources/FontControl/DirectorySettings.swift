import Foundation

public enum DirectorySettings {
    /// A root is durable in the selected registry. Changing it never discards ownership records.
    @discardableResult
    public static func setRoot(_ path: String, dryRun: Bool, state: inout Registry,
                               save: (Registry) throws -> Void) throws -> String {
        guard !path.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw FontError("Укажите путь: fontctl root set \"/путь/к/Fonts\"")
        }
        let canonical = canonicalPath(path)
        if !state.fonts.isEmpty && state.root != canonical {
            throw FontError("Есть управляемые регистрации старой папки. Сначала fontctl deactivate, затем fontctl root set \"\(canonical)\". Текущие регистрации не изменены.")
        }
        var isDirectory: ObjCBool = false
        let fm = FileManager.default
        guard fm.fileExists(atPath: canonical, isDirectory: &isDirectory), isDirectory.boolValue else {
            throw FontError("Папка недоступна: \(canonical). Сохранённый путь не изменён.")
        }
        // Verify directory access without hashing or activating fonts.
        _ = try fm.contentsOfDirectory(atPath: canonical)
        guard !dryRun, state.root != canonical else { return canonical }
        var updated = state
        updated.root = canonical; updated.scope = .persistent
        try save(updated)
        state = updated
        return canonical
    }
}
