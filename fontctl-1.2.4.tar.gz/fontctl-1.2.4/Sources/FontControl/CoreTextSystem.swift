import Foundation
import CoreText

public final class CoreTextSystem: FontSystem {
    public init() {}
    private func ctScope(_ scope: Scope) -> CTFontManagerScope { scope == .session ? .session : .persistent }
    public func scope(path: String) -> Scope? {
        switch CTFontManagerGetScopeForURL(URL(fileURLWithPath: path) as CFURL) {
        case .session: return .session
        case .persistent: return .persistent
        default: return nil
        }
    }
    public func names(path: String) throws -> [String] {
        guard let descriptors = CTFontManagerCreateFontDescriptorsFromURL(URL(fileURLWithPath: path) as CFURL) as? [CTFontDescriptor], !descriptors.isEmpty else {
            throw FontError("CoreText не распознал шрифт")
        }
        let names = descriptors.compactMap { CTFontDescriptorCopyAttribute($0, kCTFontNameAttribute) as? String }
        guard names.count == descriptors.count, names.allSatisfy({ !$0.isEmpty && $0 != "." }) else {
            throw FontError("Отсутствует пригодное внутреннее PostScript-имя; имя файла это не исправляет")
        }
        return Array(Set(names)).sorted()
    }
    public func availableNames() -> Set<String> {
        Set((CTFontManagerCopyAvailablePostScriptNames() as? [String]) ?? [])
    }
    public func register(path: String, scope: Scope) throws {
        var error: Unmanaged<CFError>?
        guard CTFontManagerRegisterFontsForURL(URL(fileURLWithPath: path) as CFURL, ctScope(scope), &error) else { throw convert(error) }
    }
    public func unregister(path: String, scope: Scope) throws {
        var error: Unmanaged<CFError>?
        guard CTFontManagerUnregisterFontsForURL(URL(fileURLWithPath: path) as CFURL, ctScope(scope), &error) else { throw convert(error) }
    }
    private func convert(_ error: Unmanaged<CFError>?) -> FontError {
        guard let error = error?.takeRetainedValue() else { return FontError("CoreText вернул ошибку без описания") }
        return FontError("\(CFErrorGetDomain(error) as String? ?? "CoreText") [\(CFErrorGetCode(error))]: \(CFErrorCopyDescription(error) as String)", code: CFErrorGetCode(error))
    }
}
