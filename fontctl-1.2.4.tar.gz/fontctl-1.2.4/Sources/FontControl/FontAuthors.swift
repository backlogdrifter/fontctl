import Foundation
import CoreText

public enum FontAuthors {
    /// Designer is the preferred attribution; manufacturer is used when no designer is recorded.
    public static func names(at path: String) -> [String] {
        guard let descriptors = CTFontManagerCreateFontDescriptorsFromURL(URL(fileURLWithPath: path) as CFURL) as? [CTFontDescriptor] else { return [] }
        var names = Set<String>()
        for descriptor in descriptors {
            let font = CTFontCreateWithFontDescriptor(descriptor, 0, nil)
            let raw = (CTFontCopyName(font, kCTFontDesignerNameKey) ?? CTFontCopyName(font, kCTFontManufacturerNameKey)) as String?
            if let name = raw?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty {
                names.insert(name)
            }
        }
        return names.sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
    }
}
