import Foundation

public enum ProgressPhase: String { case discovery, hashing, reconcile, process, authors, deactivate, status }
public struct ProgressUpdate: Equatable {
    public let phase: ProgressPhase
    public let completed: Int
    public let total: Int
    public init(_ phase: ProgressPhase, _ completed: Int, _ total: Int) {
        self.phase = phase; self.completed = completed; self.total = total
    }
}
public typealias ProgressCallback = (ProgressUpdate) -> Void

/// New activations are persistent; sync/scan retain the mode of an existing managed collection.
public func registrationScope(command: String, explicit: Scope?, state: Registry, root: String) -> Scope {
    if let explicit { return explicit }
    if command == "activate" { return .persistent }
    if state.root == root && !state.fonts.isEmpty { return state.scope }
    return .persistent
}

extension RunReport {
    public var shortSummary: String {
        let checked = Set(events.map(\.path)).count
        let en = Localization.language == "en"
        let title = command == "status" ? (en ? "In registry:" : "В реестре:") : dryRun ? (en ? "Planned:" : "План обработки:") : (en ? "Processed:" : "Обработано:")
        let labels: [(String, String)] = [
            ("registered", en ? "Activated:" : "Активировано:"), ("would-register", en ? "To activate:" : "К активации:"),
            ("active", en ? "Active:" : "Активны:"), ("recovered", en ? "Recovered records:" : "Восстановлено записей:"),
            ("unregistered", en ? "Deactivated:" : "Отключено:"), ("would-unregister", en ? "To deactivate:" : "К отключению:"),
            ("forgotten", en ? "Removed records:" : "Удалено записей:"), ("would-forget", en ? "To remove:" : "К удалению записей:"),
            ("external", en ? "Registered externally:" : "Подключены извне:"), ("inactive", en ? "Inactive:" : "Неактивны:"),
            ("conflict", en ? "Conflicts:" : "Конфликтов:"), ("invalid", en ? "Invalid:" : "Непригодных:"),
            ("changed-scope", en ? "Scope changed externally:" : "Изменён режим извне:"), ("error", en ? "Errors:" : "Ошибок:")
        ]
        let counts = self.counts
        var parts = [title.padding(toLength: 26, withPad: " ", startingAt: 0) + "\(checked)"]
        parts += labels.compactMap { key, label in
            guard let count = counts[key], count > 0 else { return nil }
            return label.padding(toLength: 26, withPad: " ", startingAt: 0) + "\(count)"
        }
        return parts.joined(separator: "\n")
    }
}
