import Foundation
import FontControl
import Darwin

/// Only runs for the lifetime of an interactive command. stdout remains clean for piping/JSON.
final class TerminalProgress {
    private let enabled: Bool
    private let command: String
    private let dryRun: Bool
    private let colorEnabled: Bool
    private let lock = NSLock()
    private var timer: DispatchSourceTimer?
    private var label = Localization.text("Reading state", "Чтение состояния")
    private var completed: Int?
    private var total: Int?
    private var frame = 0
    private var finished = false
    private let started = Date()
    private let frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    private let palette = [
        "240;90;110", "245;110;90", "245;145;75", "235;185;70",
        "200;210;75", "145;220;95", "95;220;145", "75;215;195",
        "75;185;230", "95;145;240", "135;115;235", "180;100;225",
        "220;95;185", "240;90;140"
    ]
    init(command: String, dryRun: Bool, disabled: Bool) {
        self.command = command; self.dryRun = dryRun
        colorEnabled = ProcessInfo.processInfo.environment["NO_COLOR"] == nil
        enabled = !disabled && isatty(STDERR_FILENO) == 1 && ProcessInfo.processInfo.environment["TERM"] != "dumb"
        if enabled {
            render()
            let timer = DispatchSource.makeTimerSource(queue: DispatchQueue(label: "fontctl.progress", qos: .utility))
            timer.schedule(deadline: .now() + .milliseconds(120), repeating: .milliseconds(120))
            timer.setEventHandler { [weak self] in self?.render() }
            self.timer = timer; timer.resume()
        }
    }
    func update(_ update: ProgressUpdate) {
        guard enabled else { return }
        let label: String
        switch update.phase {
        case .discovery: label = Localization.text("Scanning folders", "Сканирование папок")
        case .hashing: label = Localization.text("Reading files", "Чтение файлов")
        case .reconcile: label = Localization.text("Checking registrations", "Проверка регистраций")
        case .process: label = dryRun ? Localization.text("Checking fonts", "Проверка шрифтов") : command == "sync" ? Localization.text("Synchronizing", "Синхронизация") : Localization.text("Activating", "Активация")
        case .authors: label = Localization.text("Reading author metadata", "Чтение сведений об авторах")
        case .deactivate: label = dryRun ? Localization.text("Planning deactivation", "План отключения") : Localization.text("Deactivating", "Отключение")
        case .status: label = Localization.text("Checking status", "Проверка статуса")
        }
        lock.lock()
        let redraw = self.label != label || update.completed == 0 || update.completed == update.total
        self.label = label; completed = update.completed; total = update.total
        lock.unlock()
        if redraw { render() }
    }
    func stage(_ label: String) {
        guard enabled else { return }
        lock.lock(); self.label = label; completed = nil; total = nil; lock.unlock()
        render()
    }
    private func render() {
        lock.lock(); defer { lock.unlock() }
        guard !finished else { return }
        let time = Int(Date().timeIntervalSince(started))
        let percent = (completed != nil && total != nil && total! > 0) ? min(100, max(0, completed! * 100 / total!)) : nil
        let filled = percent.map { $0 * 28 / 100 }
        var bar = ""
        for index in 0..<28 {
            let active = filled.map { index < $0 } ?? ((index + 28 - (frame / 2) % 28) % 28 < 6)
            if colorEnabled {
                let color = active ? "\u{001B}[38;2;\(palette[(index + frame / 2) % palette.count])m" : "\u{001B}[90m"
                bar += color + "░"
            } else {
                bar += active ? "░" : "·"
            }
        }
        let amount = percent.map { "\($0)%" } ?? "..."
        var line = "\(bar)\u{001B}[0m  \(amount) \(frames[frame % frames.count]) \(label)"
        if let done = completed, let total, total > 0 { line += "  \(done)/\(total)" }
        line += "  \(time / 60):\(String(format: "%02d", time % 60))"
        FileHandle.standardError.write(Data(("\r\u{001B}[2K" + line).utf8))
        frame += 1
    }
    func finish() {
        guard enabled else { return }
        lock.lock(); defer { lock.unlock() }
        guard !finished else { return }
        finished = true; timer?.cancel(); timer = nil
        FileHandle.standardError.write(Data("\r\u{001B}[0m\u{001B}[2K".utf8))
    }
    deinit { finish() }
}
