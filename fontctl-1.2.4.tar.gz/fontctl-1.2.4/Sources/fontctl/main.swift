import Foundation
import FontControl
import Darwin

let version = "1.2.4"
var buildDate: String {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: Localization.language == "ru" ? "ru_RU" : "en_US")
    formatter.dateFormat = "LLLL yyyy"
    return formatter.string(from: Date())
}
let languageURL = URL(fileURLWithPath: NSHomeDirectory() + "/Library/Application Support/fontctl/language.txt")
func loadLanguage() {
    if let override = ProcessInfo.processInfo.environment["FONTCTL_LANGUAGE"], ["en", "ru"].contains(override) {
        Localization.language = override
        return
    }
    if let value = try? String(contentsOf: languageURL, encoding: .utf8).trimmingCharacters(in: .whitespacesAndNewlines), value == "ru" {
        Localization.language = "ru"
    }
}
let helpBody = """

╔══════════════╗
║  ███████████ ║
║ ░░███░░░░░░█ ║
║  ░███   █ ░  ║
║  ░███████    ║
║  ░███░░░█    ║
║  ░███  ░     ║
║  █████       ║
║ ░░░░░   fctl ║
╚══════════════╝

==================================
FONTCTL CLI
/font catalog command line tool/

Версия: \(version)
Сборка: \(buildDate)
Автор: backlogdrifter

Управление системной регистрацией
шрифтов из выбранной коллекции
на основе macOS CoreText
==================================

*КОМАНДЫ*
fctl              Короткое имя fontctl; принимает те же команды и аргументы
lang ru|en        Выбрать язык интерфейса; по умолчанию en
scan "path"       Проверить шрифты, не активируя их
activate "path"   Активировать шрифты
sync "path"       Синхронизировать регистрации с коллекцией
deactivate        Отключить регистрации fontctl
status            Проверить состояние регистраций
list              Вывести активные шрифты по одному на строке
authors "path"    Показать авторов шрифтов в каталоге
root get          Показать путь к коллекции
root set "path"   Сохранить путь к коллекции
help              Показать эту справку
--version         Показать версию

*ПРИМЕРЫ*
fctl scan
fctl activate --dry-run
fctl activate --family "AA Gothic (CYR)"
fctl sync
fctl list
fctl authors
fctl root set "/Volumes/Fonts"

*ПОЯСНЕНИЯ*
░  По умолчанию activate регистрирует шрифты постоянно. Для временной регистрации
   используйте --scope session. Перед сменой режима выполните deactivate;
░  Путь можно задать позиционно или через --root; приоритет: --root, FONTCTL_ROOT,
   сохранённый путь, config.root. --config указывает JSON-конфигурацию, --state —
   отдельный реестр;
░  Сканируются только OTF/TTF непосредственно внутри папок гарнитур. Файлы не
   копируются и не изменяются. Внешние регистрации не присваиваются fontctl;
░  authors берёт поле Designer; если оно пусто — Manufacturer. Имена без этих
   сведений пропускаются;
░  --dry-run показывает план; --json выводит отчёт; --report ФАЙЛ сохраняет его;
░  --verbose показывает детали, --no-progress отключает индикатор;
░  Реестр находится в ~/Library/Application Support/fontctl. Не удаляйте его,
░  пока существуют управляемые регистрации. Для работы шрифтов исходный диск
   должен быть доступен;
░  Коды завершения: 0 — успех, 1 — ошибка запуска/состояния, 2 — часть шрифтов
   пропущена из-за ошибок или конфликтов.

"""
let englishHelpBody = """

╔══════════════╗
║  ███████████ ║
║ ░░███░░░░░░█ ║
║  ░███   █ ░  ║
║  ░███████    ║
║  ░███░░░█    ║
║  ░███  ░     ║
║  █████       ║
║ ░░░░░   fctl ║
╚══════════════╝

==================================
FONTCTL CLI
/font catalog command line tool/

Version: \(version)
Build: \(buildDate)
Author: backlogdrifter

Manage font registrations
from a selected collection
using macOS CoreText
==================================

*COMMANDS*
fctl              Short alias for fontctl; accepts the same commands and options
lang ru|en        Set the interface language; default: en
scan "path"       Check fonts without activating them
activate "path"   Activate fonts
sync "path"       Reconcile registrations with the collection
deactivate        Remove registrations owned by fontctl
status            Check registrations
list              Show active fonts, one per line
authors "path"    List font designers in the collection
root get          Show the collection path
root set "path"   Save the collection path
help              Show this help
--version         Show the version

*EXAMPLES*
fctl scan
fctl activate --dry-run
fctl activate --family "AA Gothic (CYR)"
fctl sync
fctl list
fctl authors
fctl root set "/Volumes/Fonts"

*NOTES*
░  activate uses persistent registration by default. Use --scope session for temporary
   registration. Run deactivate before changing scope;
░  Set the path as an argument or with --root. Priority: --root, FONTCTL_ROOT,
   saved root, config.root. --config selects a JSON config; --state selects a registry;
░  Only direct OTF/TTF files in family folders are scanned. Files are not copied or
   modified. Registrations made elsewhere are not claimed by fontctl;
░  authors uses Designer metadata, falling back to Manufacturer. Files without
   either field are omitted;
░  --dry-run previews changes; --json prints a report; --report FILE saves it;
░  --verbose prints details; --no-progress hides the progress indicator;
░  The registry is in ~/Library/Application Support/fontctl. Keep it while managed
   registrations exist. The source disk must stay available;
░  Exit codes: 0 success, 1 launch/state error, 2 some fonts skipped due to errors
   or conflicts.

"""
func renderHelp(status: String? = nil) -> String {
    let body = Localization.language == "ru" ? helpBody : englishHelpBody
    let heading = Localization.text("*CURRENT STATUS*", "*ТЕКУЩИЙ СТАТУС*")
    let content = "\n" + body.trimmingCharacters(in: .newlines)
    return status.map { content + "\n\n" + heading + "\n" + $0 } ?? content
}

func colorizedHelp(_ text: String) -> String {
    let commandColor = "\u{001B}[1;36m"
    let pathColor = "\u{001B}[1;33m"
    let statusColor = "\u{001B}[1;32m"
    let reset = "\u{001B}[0m"
    let pattern = #""[^"\n]+"|(?<![\w-])(?:--version|deactivate|activate|status|scan|sync|list|authors|root|help|fctl|lang)(?![\w-])"#
    guard let regex = try? NSRegularExpression(pattern: pattern) else { return text }
    var inStatus = false
    return text.components(separatedBy: "\n").map { line in
        if line == "*ТЕКУЩИЙ СТАТУС*" || line == "*CURRENT STATUS*" { inStatus = true; return line }
        if line.hasPrefix("Коллекция: ") || line.hasPrefix("Collection: ") {
            let label = line.hasPrefix("Collection: ") ? "Collection: " : "Коллекция: "
            return label + pathColor + String(line.dropFirst(label.count)) + reset
        }
        if inStatus { return statusColor + line + reset }
        let matches = regex.matches(in: line, range: NSRange(location: 0, length: (line as NSString).length))
        var result = line
        for match in matches.reversed() {
            guard let range = Range(match.range, in: result) else { continue }
            let token = String(result[range])
            let color = token.hasPrefix("\"") ? pathColor : commandColor
            result.replaceSubrange(range, with: color + token + reset)
        }
        return result
    }.joined(separator: "\n")
}

func printHelp(status: String? = nil) {
    let content = renderHelp(status: status)
    guard isatty(STDOUT_FILENO) == 1,
          ProcessInfo.processInfo.environment["TERM"] != "dumb",
          ProcessInfo.processInfo.environment["NO_COLOR"] == nil else {
        print(colorizedHelp(content))
        return
    }
    let lines = content.components(separatedBy: "\n")
    guard let first = lines.firstIndex(where: { $0.hasPrefix("╔") }),
          let last = lines.firstIndex(where: { $0.hasPrefix("╚") }), last >= first else {
        print(colorizedHelp(content))
        return
    }
    let banner = Array(lines[first...last])
    let palette = [
        "240;90;110", "245;110;90", "245;145;75", "235;185;70",
        "200;210;75", "145;220;95", "95;220;145", "75;215;195",
        "75;185;230", "95;145;240", "135;115;235", "180;100;225",
        "220;95;185", "240;90;140"
    ]
    FileHandle.standardOutput.write(Data("\n".utf8))
    for frame in 0..<26 {
        if frame > 0 {
            FileHandle.standardOutput.write(Data("\u{001B}[\(banner.count)A".utf8))
        }
        let image = banner.map { line in
            line.enumerated().map { index, character -> String in
                let animated = character == "░" || (line.contains("fctl") && index >= 10 && index <= 13)
                guard animated else { return String(character) }
                let color = palette[(index + frame) % palette.count]
                return "\u{001B}[38;2;\(color)m\(character)\u{001B}[0m"
            }.joined()
        }.joined(separator: "\n") + "\n"
        FileHandle.standardOutput.write(Data(colorizedHelp(image).utf8))
        if frame < 25 { Thread.sleep(forTimeInterval: 0.08) }
    }
    print(colorizedHelp(lines.dropFirst(last + 1).joined(separator: "\n")))
}

func colorizedResult(_ report: RunReport) -> String {
    let summary = report.shortSummary
    guard isatty(STDOUT_FILENO) == 1,
          ProcessInfo.processInfo.environment["NO_COLOR"] == nil else { return summary }
    return summary.components(separatedBy: "\n").enumerated().map { index, part in
        let color: String
        if ["Ошибок:", "Конфликтов:", "Непригодных:", "Errors:", "Conflicts:", "Invalid:"].contains(where: { part.hasPrefix($0) }) { color = "31" }
        else if ["Изменён режим", "Неактивны:", "Scope changed", "Inactive:"].contains(where: { part.hasPrefix($0) }) { color = "33" }
        else { color = index == 0 ? "36" : "32" }
        return "\u{001B}[1;\(color)m\(part)\u{001B}[0m"
    }.joined(separator: "\n")
}

struct Options {
    var command = "status"
    var root: String?
    var rootAction = "get"
    var family: String?
    var scope: Scope?
    var dryRun = false
    var json = false
    var verbose = false
    var noProgress = false
    var report: String?
    var config: String?
    var state = NSHomeDirectory() + "/Library/Application Support/fontctl/state.json"
    init(_ arguments: [String]) throws {
        var args = arguments
        if let first = args.first, !first.hasPrefix("-") { command = first; args.removeFirst() }
        guard ["scan", "activate", "deactivate", "sync", "status", "list", "authors", "root"].contains(command) else { throw FontError("Неизвестная команда: \(command)") }
        var rootActionParsed = false
        var index = 0
        while index < args.count {
            let arg = args[index]
            if command == "root", ["get", "set"].contains(arg), !rootActionParsed, root == nil {
                rootAction = arg; rootActionParsed = true; index += 1; continue
            }
            func value() throws -> String {
                guard index + 1 < args.count else { throw FontError("Нет значения для \(arg)") }
                index += 1; return args[index]
            }
            switch arg {
            case "--root": guard root == nil else { throw FontError("Путь указан дважды") }; root = try value()
            case "--family": family = try value()
            case "--scope":
                let v = try value(); guard let scope = Scope(rawValue: v) else { throw FontError("Режим: session или persistent") }; self.scope = scope
            case "--dry-run": dryRun = true
            case "--json": json = true
            case "--verbose": verbose = true
            case "--no-progress": noProgress = true
            case "--report": report = try value()
            case "--state": state = try value()
            case "--config": config = try value()
            default:
                guard !arg.hasPrefix("-"), root == nil else { throw FontError("Неизвестный аргумент: \(arg)") }
                root = arg
            }
            index += 1
        }
        if command == "root" {
            guard family == nil && scope == nil else { throw FontError("--family и --scope не используются с root") }
            guard (rootAction == "set") == (root != nil) else {
                throw FontError(rootAction == "set" ? "Укажите путь: fontctl root set /путь/к/Fonts" : "Для смены пути используйте root set ПУТЬ")
            }
        }
        if let family, family.isEmpty || family == "." || family == ".." || family.contains("/") {
            throw FontError("--family должен содержать одно имя папки")
        }
        if ["status", "deactivate", "authors"].contains(command) && scope != nil { throw FontError("--scope задаётся при activate/sync") }
    }
}
func run() throws -> Int32 {
    loadLanguage()
    let args = Array(CommandLine.arguments.dropFirst())
    if args.first == "lang" {
        guard args.count <= 2, args.count == 1 || ["ru", "en"].contains(args[1]) else {
            throw FontError(Localization.text("Usage: fontctl lang ru|en", "Использование: fontctl lang ru|en"))
        }
        if args.count == 2 {
            try FileManager.default.createDirectory(at: languageURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            try Data((args[1] + "\n").utf8).write(to: languageURL, options: .atomic)
            Localization.language = args[1]
        }
        print(Localization.text("Language: \(Localization.language)", "Язык: \(Localization.language)"))
        return 0
    }
    if args.contains("--version") { print("fontctl \(version)"); return 0 }
    if args.first == "help" || args.contains("--help") || args.contains("-h") { printHelp(); return 0 }
    if args.isEmpty || args.first == "--config" || args.first == "--state" {
        var statePath = NSHomeDirectory() + "/Library/Application Support/fontctl/state.json"
        var configPath: String?
        var index = 0
        while index < args.count {
            if args[index] == "--state", index + 1 < args.count { statePath = args[index + 1]; index += 2; continue }
            if args[index] == "--config", index + 1 < args.count { configPath = args[index + 1]; index += 2; continue }
            index += 1
        }
        let store = StateStore(path: statePath)
        try store.lock()
        var state = try store.load()
        if let configPath, state.root == nil {
            struct Config: Decodable { let root: String }
            state.root = try JSONDecoder().decode(Config.self, from: Data(contentsOf: URL(fileURLWithPath: (configPath as NSString).expandingTildeInPath))).root
        }
        let report = Controller(system: CoreTextSystem()).status(state: state)
        var status = report.shortSummary
        if let root = state.root { status += "\n" + Localization.text("Collection: ", "Коллекция: ") + root }
        printHelp(status: status)
        return report.hasErrors ? 2 : 0
    }
    let options = try Options(args)
    let progress = TerminalProgress(command: options.command,
                                    dryRun: options.dryRun || options.command == "scan",
                                    disabled: options.json || options.noProgress)
    defer { progress.finish() }
    let store = StateStore(path: options.state)
    if let report = options.report {
        let path = URL(fileURLWithPath: (report as NSString).expandingTildeInPath).standardizedFileURL.path
        guard ![store.url.path, store.url.path + ".journal", store.url.path + ".lock"].contains(path) else {
            throw FontError("Отчёт не может перезаписывать состояние или журнал")
        }
    }
    try store.lock()
    var state = try store.load()
    var configRoot: String?
    if let path = options.config {
        struct Config: Decodable { let root: String }
        configRoot = try JSONDecoder().decode(Config.self, from: Data(contentsOf: URL(fileURLWithPath: (path as NSString).expandingTildeInPath))).root
    }
    let suppliedRoot = options.root ?? ProcessInfo.processInfo.environment["FONTCTL_ROOT"]
    let root = (suppliedRoot ?? state.root ?? configRoot).map(canonicalPath)
    if ["deactivate", "status", "list"].contains(options.command), let suppliedRoot, let ownedRoot = state.root,
       canonicalPath(suppliedRoot) != ownedRoot { throw FontError("Этот --state относится к другой папке: \(ownedRoot)") }
    if options.command == "root" {
        struct RootReport: Encodable {
            let command = "root"
            let action: String
            let root: String
            let changed: Bool
            let dryRun: Bool
        }
        let selected: String
        let previous = state.root
        if options.rootAction == "set" {
            selected = try DirectorySettings.setRoot(options.root!, dryRun: options.dryRun, state: &state) {
                progress.stage(Localization.text("Saving collection path", "Сохранение папки"))
                try store.checkpoint($0)
            }
        } else {
            guard let root else { throw FontError("Папка не задана. Используйте fontctl root set ПУТЬ") }
            selected = root
        }
        let result = RootReport(action: options.rootAction, root: selected,
                                changed: options.rootAction == "set" && previous != selected && !options.dryRun,
                                dryRun: options.dryRun)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        let data = try encoder.encode(result)
        if let path = options.report {
            try data.write(to: URL(fileURLWithPath: (path as NSString).expandingTildeInPath), options: .atomic)
        }
        progress.finish()
        if options.json { print(String(decoding: data, as: UTF8.self)) }
        else {
            let label = options.rootAction == "set" ? (options.dryRun ? Localization.text("Planned collection path", "План смены папки") : Localization.text("Collection path saved", "Папка сохранена")) : Localization.text("Collection path", "Папка")
            print("\(label): \(selected)")
        }
        return 0
    }
    if options.command == "authors" {
        guard let root else { throw FontError(Localization.text("No collection path set. Use fontctl root set PATH", "Папка не задана. Используйте fontctl root set ПУТЬ")) }
        let files = try Scanner.scan(root: root, family: options.family, progress: progress.update, hashFiles: false)
        progress.update(ProgressUpdate(.authors, 0, files.count))
        var authors = Set<String>()
        var missing = 0
        for (index, file) in files.enumerated() {
            let names = FontAuthors.names(at: file.path)
            if names.isEmpty { missing += 1 }
            authors.formUnion(names)
            progress.update(ProgressUpdate(.authors, index + 1, files.count))
        }
        let sorted = authors.sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
        struct AuthorsReport: Encodable {
            let command = "authors"
            let root: String
            let authors: [String]
            let scannedFiles: Int
            let filesWithoutAttribution: Int
        }
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        let data = try encoder.encode(AuthorsReport(root: root, authors: sorted, scannedFiles: files.count, filesWithoutAttribution: missing))
        if let path = options.report {
            try data.write(to: URL(fileURLWithPath: (path as NSString).expandingTildeInPath), options: .atomic)
        }
        progress.finish()
        if options.json { print(String(decoding: data, as: UTF8.self)) }
        else if sorted.isEmpty { print(Localization.text("No author metadata found", "Сведения об авторах не найдены")) }
        else { sorted.forEach { print($0) } }
        return 0
    }
    let system = CoreTextSystem(); let controller = Controller(system: system)
    let report: RunReport
    switch options.command {
    case "status": report = controller.status(state: state, family: options.family, progress: progress.update)
    case "list": report = controller.status(state: state, family: options.family, progress: progress.update)
    case "deactivate": report = try controller.deactivate(family: options.family, dryRun: options.dryRun, state: &state, progress: progress.update, save: store.save)
    default:
        guard let root else { throw FontError("Укажите путь к Fonts или используйте проектный launcher ./fontctl") }
        let files = try Scanner.scan(root: root, family: options.family, progress: progress.update)
        report = try controller.apply(command: options.command, root: root, files: files,
                                      scope: registrationScope(command: options.command, explicit: options.scope, state: state, root: root),
                                      family: options.family, dryRun: options.dryRun || options.command == "scan",
                                      state: &state, progress: progress.update, save: store.save)
    }
    if ["activate", "sync", "deactivate"].contains(options.command) && !options.dryRun {
        progress.stage(Localization.text("Saving state", "Сохранение состояния"))
        try store.checkpoint(state)
    }
    progress.stage(Localization.text("Preparing report", "Подготовка отчёта"))
    let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
    let data = try encoder.encode(report)
    if let path = options.report {
        let url = URL(fileURLWithPath: (path as NSString).expandingTildeInPath)
        guard url.standardizedFileURL.path != store.url.path else { throw FontError("Отчёт не может перезаписывать файл состояния") }
        try data.write(to: url, options: .atomic)
    }
    progress.finish()
    if options.json { print(String(decoding: data, as: UTF8.self)) }
    else if options.command == "list" {
        let names = report.events.filter { $0.action == "active" }.compactMap { state.fonts[$0.path] }.flatMap(\.names).sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
        if names.isEmpty { print(Localization.text("No active fonts", "Активных шрифтов нет")) }
        else { names.forEach { print($0) } }
    }
    else {
        print(colorizedResult(report))
        if options.verbose {
            for event in report.events {
                print("[\(event.action)] \(event.path)\(event.detail.isEmpty ? "" : " — " + event.detail)")
            }
        }
    }
    return report.hasErrors ? 2 : 0
}
do { exit(try run()) }
catch { FileHandle.standardError.write(Data(("fontctl: \(error.localizedDescription)\n").utf8)); exit(1) }
